Maktab Islami 5.3 — restored 4.9 Quran engine + 9 offline hadith books.

The Quran UI/reader is preserved from the uploaded 4.9 APK.
Only the local data path is restored and the hadith loader is extended
to read data.items from the bundled 5.3 JSON files.
