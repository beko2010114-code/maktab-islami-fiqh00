package com.maktabislami.fiqh;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class PdfActivity extends Activity {
    private PdfRenderer renderer;
    private PdfRenderer.Page page;
    private ImageView image;
    private TextView counter;
    private int index=0;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        String asset=getIntent().getStringExtra("asset"); String title=getIntent().getStringExtra("title");
        try{File f=new File(getCacheDir(),"book.pdf"); InputStream in=getAssets().open(asset); FileOutputStream out=new FileOutputStream(f); byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0)out.write(buf,0,n); in.close(); out.close(); renderer=new PdfRenderer(ParcelFileDescriptor.open(f,ParcelFileDescriptor.MODE_READ_ONLY));
        }catch(Exception e){ TextView t=new TextView(this); t.setText("تعذر فتح الكتاب: "+e.getMessage()); t.setPadding(30,30,30,30); setContentView(t); return; }
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,10,10,10);
        TextView h=new TextView(this); h.setText(title==null?"الكتاب":title); h.setTextSize(20); h.setGravity(Gravity.CENTER); h.setPadding(5,5,5,12); root.addView(h);
        image=new ImageView(this); image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); root.addView(image,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setGravity(Gravity.CENTER); Button prev=new Button(this); prev.setText("السابق"); Button next=new Button(this); next.setText("التالي"); counter=new TextView(this); counter.setPadding(18,0,18,0); nav.addView(prev); nav.addView(counter); nav.addView(next); root.addView(nav);
        prev.setOnClickListener(v->{if(index>0){index--;showPage();}}); next.setOnClickListener(v->{if(index<renderer.getPageCount()-1){index++;showPage();}}); setContentView(root); showPage();
    }
    private void showPage(){ if(page!=null)page.close(); page=renderer.openPage(index); Bitmap bmp=Bitmap.createBitmap(page.getWidth(),page.getHeight(),Bitmap.Config.ARGB_8888); page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); image.setImageBitmap(bmp); counter.setText((index+1)+" / "+renderer.getPageCount()); }
    @Override protected void onDestroy(){if(page!=null)page.close(); if(renderer!=null)renderer.close(); super.onDestroy();}
}
