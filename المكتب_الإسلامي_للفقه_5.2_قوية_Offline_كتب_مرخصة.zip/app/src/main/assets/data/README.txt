OFFLINE CONTENT

The build workflow downloads and validates the Quran and hadith datasets at build time,
then packages the resulting JSON files into the APK assets. The runtime app never fetches
religious content from the network.

Quran: semarketir/quranjson (MIT), 114 surahs / 6236 verses.
Hadith: AhmedBaset/hadith-json v1.2.0. See its repository for source/license and attribution.
