#!/usr/bin/env python3
import json
import os
import urllib.request

BASE = "https://raw.githubusercontent.com/AhmedBaset/hadith-json/v1.2.0/db/by_book/the_9_books"
DATA = os.path.join("app", "src", "main", "assets", "data", "hadith")

books = {
    "bukhari.json": f"{BASE}/bukhari.json",
    "muslim.json": f"{BASE}/muslim.json",
}

os.makedirs(DATA, exist_ok=True)

for filename, url in books.items():
    target = os.path.join(DATA, filename)
    print(f"Fetching {filename} ...")
    with urllib.request.urlopen(url, timeout=60) as r:
        content = r.read()
    if len(content) < 1000:
        raise RuntimeError(f"Downloaded file is unexpectedly small: {filename}")
    with open(target, "wb") as f:
        f.write(content)
    # Validate JSON before the APK build.
    with open(target, "r", encoding="utf-8") as f:
        json.load(f)
    print(f"OK: {target} ({len(content):,} bytes)")
