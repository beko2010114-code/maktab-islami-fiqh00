#!/usr/bin/env python3
"""Build-time downloader for the large offline Islamic content pack.
All downloaded datasets are kept attributed and pinned to known versions where available.
"""
from pathlib import Path
from urllib.request import Request, urlopen
import json, time
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'app'/'src'/'main'/'assets'/'data'
HAD=DATA/'hadith'; HAD.mkdir(parents=True,exist_ok=True); DATA.mkdir(parents=True,exist_ok=True)

def get(url, timeout=120):
    req=Request(url,headers={'User-Agent':'Maktab-Islami-Fiqh/2.0 data-builder'})
    with urlopen(req,timeout=timeout) as r:return r.read()
def save(url,path):
    print('GET',url); b=get(url); path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_bytes(b); tmp.replace(path); print(' ->',path,len(b))

# Quran text (existing app source is preserved; this also makes CI reproducible)
save('https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json',DATA/'quran.json')

# Two full Arabic tafsir datasets explicitly permitted for redistribution by QuranEnc, subject to attribution/version rules.
for key,fn,title in [('arabic_moyassar','tafsir_muyassar.json','التفسير الميسر'),('arabic_saadi','tafsir_saadi.json','تفسير السعدي')]:
    all_s={}
    for sura in range(1,115):
        all_s[str(sura)]=json.loads(get(f'https://quranenc.com/api/v1/translation/sura/{key}/{sura}').decode())
        if sura%10==0: print(key,sura,'/114')
    (DATA/fn).write_text(json.dumps({'source':'QuranEnc.com','translation_key':key,'title':title,'surahs':all_s},ensure_ascii=False,separators=(',',':')),encoding='utf-8')

# 17-book Arabic hadith corpus, pinned to AhmedBaset/hadith-json v1.2.0.
# The source project documents 50,884 hadiths and 17 books; we keep its attribution in sources.json.
books={
'bukhari':'the_9_books/bukhari.json','muslim':'the_9_books/muslim.json','abudawud':'the_9_books/abudawud.json','tirmidhi':'the_9_books/tirmidhi.json','nasai':'the_9_books/nasai.json','ibnmajah':'the_9_books/ibnmajah.json','malik':'the_9_books/malik.json','ahmad':'the_9_books/ahmad.json','darimi':'the_9_books/darimi.json',
'riyad_assalihin':'other_books/riyad_assalihin.json','shamail_muhammadiyah':'other_books/shamail_muhammadiyah.json','bulugh_almaram':'other_books/bulugh_almaram.json','aladab_almufrad':'other_books/aladab_almufrad.json','mishkat_almasabih':'other_books/mishkat_almasabih.json','nawawi40':'forties/nawawi40.json','qudsi40':'forties/qudsi40.json','shahwaliullah40':'forties/shahwaliullah40.json'}
for key,rel in books.items():
    save('https://raw.githubusercontent.com/AhmedBaset/hadith-json/v1.2.0/db/by_book/'+rel,HAD/f'{key}.json')

manifest={'version':'2.0.0','quran':{'dataset':'quran-json 3.1.2','url':'https://github.com/risan/quran-json'},'tafsir':[{'name':'التفسير الميسر','provider':'QuranEnc.com','key':'arabic_moyassar','url':'https://quranenc.com/ar/browse/arabic_moyassar/','redistribution':'per QuranEnc terms: no modification, attribution, version retention'},{'name':'تفسير السعدي','provider':'QuranEnc.com','key':'arabic_saadi','url':'https://quranenc.com/ar/','redistribution':'per QuranEnc terms: no modification, attribution, version retention'}],'hadith':{'provider':'AhmedBaset/hadith-json','version':'v1.2.0','url':'https://github.com/AhmedBaset/hadith-json','books':list(books.keys()),'note':'Source README states 17 books and 50,884 hadiths; verify source terms before commercial distribution.'}}
(DATA/'sources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print('COMPREHENSIVE DATA BUILD COMPLETE')
