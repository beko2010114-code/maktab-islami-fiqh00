#!/usr/bin/env python3
import json, os, pathlib, urllib.request, time

ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'app/src/main/assets/data'
DATA.mkdir(parents=True, exist_ok=True)

# Quran JSON: pinned release. Build-time only; never fetched by the app.
quran_url='https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json'
out=DATA/'quran.json'
if not out.exists() or out.stat().st_size < 100000:
    print('Downloading Quran JSON for build...')
    urllib.request.urlretrieve(quran_url, out)

# QuranEnc tafsir: one JSON file per sura, assembled into one local bundle.
def fetch_qe(key, filename):
    target=DATA/filename
    if target.exists() and target.stat().st_size > 10000:
        return
    rows=[]
    for sura in range(1,115):
        url=f'https://quranenc.com/api/v1/translation/sura/{key}/{sura}'
        with urllib.request.urlopen(url, timeout=60) as r:
            obj=json.load(r)
        rows.append(obj)
        time.sleep(0.05)
    target.write_text(json.dumps({'translation_key':key,'surahs':{str(i+1):rows[i] for i in range(114)},'source':'QuranEnc.com'}, ensure_ascii=False), encoding='utf-8')

fetch_qe('arabic_moyassar','tafsir_muyassar.json')
fetch_qe('arabic_saadi','tafsir_saadi.json')

# Hadith books pinned to v1.2.0.
books={
'bukhari':'the_9_books/bukhari','muslim':'the_9_books/muslim','abudawud':'the_9_books/abudawud','tirmidhi':'the_9_books/tirmidhi','nasai':'the_9_books/nasai','ibnmajah':'the_9_books/ibnmajah','malik':'the_9_books/malik','ahmad':'the_9_books/ahmad','darimi':'the_9_books/darimi','riyad_assalihin':'other_books/riyad_assalihin','shamail_muhammadiyah':'other_books/shamail_muhammadiyah','bulugh_almaram':'other_books/bulugh_almaram','aladab_almufrad':'other_books/aladab_almufrad','mishkat_almasabih':'other_books/mishkat_almasabih','nawawi40':'other_books/nawawi40','qudsi40':'other_books/qudsi40','shahwaliullah40':'other_books/shahwaliullah40'}
base='https://raw.githubusercontent.com/AhmedBaset/hadith-json/v1.2.0/db/by_book/'
for name,path in books.items():
    target=DATA/'hadith'/f'{name}.json'
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.stat().st_size > 1000:
        continue
    url=base+path+'.json'
    try:
        urllib.request.urlretrieve(url, target)
    except Exception as e:
        print('WARNING:', name, e)

print('Offline data preparation complete.')
