# Maktab Islami 4.3

- Version bumped to 4.3.0.
- Added search type filters for Quran, Hadith, Fiqh, and Library.
- Added Enter-to-search behavior.
- Added lightweight relevance ordering for local search results.
- GitLab artifact name updated to `maktab-islami-4.3-offline.apk`.
- No network download is required during app use; only bundled local data is searchable.
- Full book text is not invented or generated when licensed source files are absent.
