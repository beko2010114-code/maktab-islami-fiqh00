# Maktab Islami 4.9

## Added
- Full JSON data for Sahih al-Bukhari and Sahih Muslim is fetched during GitHub Actions from a pinned v1.2.0 source.
- The downloaded JSON is validated and then bundled into the Android APK under `assets/data/hadith/`.
- The APK remains Offline after installation; the Internet is used only by the build job.

## Source
AhmedBaset/hadith-json, pinned to v1.2.0.

Important: the upstream project itself recommends pinning to a tag rather than `main`, and its issue tracker contains reported data-quality issues. Treat this dataset as a build input and review it before publishing a production release.
