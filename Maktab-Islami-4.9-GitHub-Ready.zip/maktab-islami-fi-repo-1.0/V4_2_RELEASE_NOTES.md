# Maktab Islami 4.2

## What changed
- Added a versioned local search index at `app/src/main/assets/data/search_index.json`.
- Added Arabic normalization for local search (hamza/taa marbuta/alif maqsura and diacritics).
- Search now combines the local index with the Quran metadata, fiqh catalog, and any locally loaded hadith data.
- Search results are capped at 200 for UI performance and report the number of matching local records.
- Updated the content manifest to identify the 4.2 offline-search feature set.

## Important
This release improves the offline search infrastructure and catalog. It does not claim that full text for every catalogued book is embedded. Full-text search only works over datasets actually packaged in the APK.
